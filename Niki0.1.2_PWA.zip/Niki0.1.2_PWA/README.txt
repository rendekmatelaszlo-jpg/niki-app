Niki0.1.2 PWA

Használat:
1. Töltsd fel ezt a mappát vagy a zipet egy webtárhelyre.
2. Nyisd meg Chrome-ban.
3. Menü -> Kezdőképernyőhöz adás / App telepítése.

Frissítés:
- Ugyanezt az appot frissítheted új fájlokkal.
- Ha verziót váltasz, a service-worker.js CACHE_NAME értékét érdemes növelni.
